// Instruction (top)

// always white for the instruction
draw_set_color(c_white);
draw_text(room_width/2, 40, "Find the LIZARD!");

// Feedback (center of screen)
if (global.message != "") {
    if (string_pos("not", global.message) > 0) {
        // Wrong choice → red
        draw_set_color(c_red);
    } else {
        // Correct choice → green
        draw_set_color(c_lime);
    }
    draw_text(room_width/2, room_height/2, global.message);
}
