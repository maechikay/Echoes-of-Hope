is_correct = false;
global.message = ""; // text to show to player
