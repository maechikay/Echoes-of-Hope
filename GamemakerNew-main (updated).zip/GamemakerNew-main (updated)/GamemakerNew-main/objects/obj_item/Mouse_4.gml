if (is_correct) {
    global.message = "You found the lizard!";
    alarm[0] = room_speed * 2; // after 2 seconds, continue
} else {
    global.message = "That's not the lizard!";
    alarm[1] = room_speed * 2; // after 2 seconds, clear message
}
