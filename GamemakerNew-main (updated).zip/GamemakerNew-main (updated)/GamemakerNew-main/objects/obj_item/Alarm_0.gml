room_goto(ending); // go back to narration
