global.message = ""; // clear the message
