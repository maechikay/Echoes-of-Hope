// Step Event
switch (state) {
    case "fadein":
        fade_alpha += fade_speed;
        if (fade_alpha >= 1) {
            fade_alpha = 1;
            state = "hold";
        }
        break;

    case "hold":
        hold_counter++;
        if (hold_counter >= hold_time) {
            state = "fadeout";
        }
        break;

    case "fadeout":
        fade_alpha -= fade_speed;
        if (fade_alpha <= 0) {
            fade_alpha = 0;
            state = "done";
            room_goto(Day_3_Summary); // go to the next room
        }
        break;
}
