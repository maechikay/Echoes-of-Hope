// --- CREATE EVENT ---
// Initializes all variables for the cutscene system.
// This event is run only once when the object is first created in a room.

// A global flag to signal a completed game.
global.game_complete = false;

// Cutscene control
cutscene_step = 0;
cutscene_timer = 0;
global.cutscene_active = true;

// If the global game completion flag is true, we immediately jump to the
// correct dialogue step upon creation in the new room.
if (global.game_complete) {
    cutscene_step = 2;
    global.game_complete = false; // Reset the flag
}

// Set default cutscene if not already set
if (!variable_global_exists("cutscene_id")) { 
    global.cutscene_id = 0; 
}
cutscene_id = global.cutscene_id;

// Fade
fade_alpha = 1;

// Dialogue system
dialogue_visible = false;
dialogue_speaker = "";
current_dialogue = "";
displayed_text = "";
typewriter_speed = 1.2;
typewriter_counter = 0;
typewriter_index = 0;

// Choices
choice_active = false;
choice_options = [];
choice_selected = 0;
choice_made = false;
choice_result = -1;

if (!variable_global_exists("player_mood")) { 
    global.player_mood = 0; 
}
player_mood = global.player_mood;


// Helper
dialogue_stage = 0;