// CREATE

// Cutscene control
cutscene_step = -1;
cutscene_timer = 0;
global.cutscene_active = true;

// Set default cutscene if not already set
if (!variable_global_exists("cutscene_id")) { global.cutscene_id = 0; }
cutscene_id = global.cutscene_id;

// Fade
fade_alpha = 1;

// Dialogue system
dialogue_visible = false;
dialogue_speaker = "";
current_dialogue = "";
displayed_text = "";
typewriter_speed = 1.2;
typewriter_counter = 0;
typewriter_index = 0;

// Choices
choice_active = false;
choice_options = [];
choice_selected = 0;
choice_made = false;
choice_result = -1;

if (!variable_global_exists("player_mood")) { global.player_mood = 0; }
player_mood = global.player_mood;


// Helper
dialogue_stage = 0;

// --- Intro card setup (Day 3)
intro_alpha = 0;           // fade control
intro_timer = 0;           // to count time
intro_state = 0;           // 0 = fade in, 1 = hold, 2 = fade out, 3 = done
cutscene_step = -1;        // start with Day 2 intro