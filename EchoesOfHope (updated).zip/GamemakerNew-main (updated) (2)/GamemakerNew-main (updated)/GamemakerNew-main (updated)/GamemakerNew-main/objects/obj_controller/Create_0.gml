// --- CREATE EVENT ---
// This event is run once when the object is created in the room.
// It's used to initialize all the variables we'll need for the game.

// State Machine for the game
enum ReactionState {
    READY,          // Waiting for player to press space to begin
    WAITING_TO_START, // Waiting for a random duration before the sequence starts
    RED,            // Flashing red light
    YELLOW,         // Flashing yellow light
    GREEN,          // Flashing green light
    GAME_OVER_WIN,  // Player successfully hit on green
    GAME_OVER_LOSE  // Player failed (too early, too late)
}

// Variables for game state
state = ReactionState.READY;
current_round = 1;

// Round difficulty settings (in frames, 60 frames = 1 second)
// The values represent how long each color stays on screen.
// Harder rounds have faster color changes.
// Adjust these values to change the difficulty.
// This has been changed from a struct to an array to fix the GM1041 error.
difficulty_rounds = [
    { red_time: 120, yellow_time: 90, green_time: 60 }, // Easy
    { red_time: 90, yellow_time: 60, green_time: 45 },  // Medium
    { red_time: 60, yellow_time: 45, green_time: 30 }   // Hard
];

// Game timers and tracking
timer = 0;
target_time = 0;
target_random_wait_frames = 0;
round_win = false; // Flag to track if the current round was won

// Visuals for the circle
circle_x = display_get_gui_width() / 2;
circle_y = display_get_gui_height() / 2;
circle_radius = 100;
circle_color = c_black;


