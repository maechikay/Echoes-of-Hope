// --- DRAW EVENT ---
// This event is responsible for all drawing on the screen.

// Draw the circle
draw_set_color(circle_color);
draw_circle(circle_x, circle_y, circle_radius, false);

// Draw the instructions and game state text
draw_set_halign(fa_left); // Change to left alignment
draw_set_valign(fa_middle);
draw_set_color(c_white);

// Determine which text to draw based on the current state.
var text_to_draw = "";
switch (state) {
    case ReactionState.READY:
        if (current_round == 1) {
            text_to_draw = "Are you ready? Press SPACE to begin\nRound 1: EASY";
        } else if (current_round == 2) {
            text_to_draw = "Are you ready? Press SPACE to begin\nRound 2: MEDIUM";
        } else {
            text_to_draw = "Are you ready? Press SPACE to begin\nRound 3: HARD";
        }
        break;

    case ReactionState.WAITING_TO_START:
    case ReactionState.RED:
    case ReactionState.YELLOW:
    case ReactionState.GREEN:
        text_to_draw = "Watch the circle!";
        break;

    case ReactionState.GAME_OVER_WIN:
        if (current_round == 3) {
            text_to_draw = "Game over, you win!\nPress SPACE to continue.";
        } else {
            text_to_draw = "You win!\nPress SPACE to continue.";
        }
        break;

    case ReactionState.GAME_OVER_LOSE:
        text_to_draw = "Too early or too late!\nPress SPACE to try again.";
        break;
}

// Position the text to the right of the circle
var text_x = circle_x + circle_radius + 20;

// Draw the selected text beside the circle.
draw_text(text_x, circle_y, text_to_draw);