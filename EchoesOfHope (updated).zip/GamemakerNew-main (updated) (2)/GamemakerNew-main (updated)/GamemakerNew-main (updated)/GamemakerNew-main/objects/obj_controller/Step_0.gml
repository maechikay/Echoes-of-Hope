// --- STEP EVENT ---
// This event runs every single frame. It contains the game's core logic.
// We use a state machine to control the flow of the game.

switch (state) {
    case ReactionState.READY:
        // Wait for player input to start the first round.
        if (keyboard_check_pressed(vk_space)) {
            // Set a random waiting period before the color sequence begins
            target_random_wait_frames = irandom_range(30, 90);
            timer = 0;
            state = ReactionState.WAITING_TO_START;
        }
        break;

    case ReactionState.WAITING_TO_START:
        timer++;
        if (timer >= target_random_wait_frames) {
            timer = 0;
            // Now accessing the array directly
            target_time = difficulty_rounds[current_round - 1].red_time;
            state = ReactionState.RED;
        }
        // Player presses space here, it's a loss
        if (keyboard_check_pressed(vk_space)) {
            state = ReactionState.GAME_OVER_LOSE;
        }
        break;

    case ReactionState.RED:
        circle_color = c_red;
        timer++;
        if (keyboard_check_pressed(vk_space)) {
            state = ReactionState.GAME_OVER_LOSE;
        }
        if (timer >= target_time) {
            timer = 0;
            // Now accessing the array directly
            target_time = difficulty_rounds[current_round - 1].yellow_time;
            state = ReactionState.YELLOW;
        }
        break;

    case ReactionState.YELLOW:
        circle_color = c_yellow;
        timer++;
        if (keyboard_check_pressed(vk_space)) {
            state = ReactionState.GAME_OVER_LOSE;
        }
        if (timer >= target_time) {
            timer = 0;
            // Now accessing the array directly
            target_time = difficulty_rounds[current_round - 1].green_time;
            state = ReactionState.GREEN;
        }
        break;

    case ReactionState.GREEN:
        circle_color = c_green;
        timer++;
        // Check if player hits space in the green window
        if (keyboard_check_pressed(vk_space)) {
            round_win = true;
            state = ReactionState.GAME_OVER_WIN;
        }
        // If the timer runs out and they haven't hit space, they lose
        if (timer >= target_time) {
            state = ReactionState.GAME_OVER_LOSE;
        }
        break;

       case ReactionState.GAME_OVER_WIN:
        if (keyboard_check_pressed(vk_space)) {
            // Advance to the next round
            current_round++;
            if (current_round > 3) {
                // Set a global variable to signal the cutscene to start after the game
                global.from_game = true;
                // Player won the whole game! Go to the next scene.
                room_goto(school_day2_scene1_1);
            } else {
                // Go to the next round
                state = ReactionState.READY;
                round_win = false; // Reset the win flag for the new round
            }
        }
        break;


    case ReactionState.GAME_OVER_LOSE:
        if (keyboard_check_pressed(vk_space)) {
            // The game will restart on the current round.
            state = ReactionState.READY;
        }
        break;
}

